'use client'
import { useState } from "react";

export default function Page() {
  const [projectName, setProjectName] = useState("");
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!projectName || !file) {
      setStatus("⚠️ Isi nama & pilih file .zip");
      return;
    }
    setStatus("🚀 Mengunggah...");
    const fd = new FormData();
    fd.append("projectName", projectName);
    fd.append("file", file);
    try {
      const res = await fetch("/api/proxy", { method: "POST", body: fd });
      const data = await res.json();
      if (res.ok) {
        setStatus("✅ Berhasil: " + (data.url || data.message || ""));
        if (data.url) window.open(data.url, "_blank");
      } else {
        setStatus("❌ Gagal: " + (data.error || data.message || ""));
      }
    } catch (err) {
      setStatus("❌ Error jaringan");
    }
  };

  return (
    <main style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(180deg,#050013,#00102a)',color:'#cff',fontFamily:'Orbitron, sans-serif',padding:20}}>
      <div style={{width:380,maxWidth:'95%',padding:28,background:'rgba(0,0,0,0.5)',borderRadius:14,boxShadow:'0 8px 30px rgba(0,255,255,0.05)',border:'1px solid rgba(0,255,255,0.08)'}}>
        <h1 style={{margin:0,fontSize:28,color:'#00f7ff',textShadow:'0 0 12px rgba(0,255,255,0.2)'}}>YannDev</h1>
        <p style={{color:'#a8c0d8',marginTop:6,marginBottom:16}}>Cyberpunk Minimal — Deploy ke Vercel</p>
        <form onSubmit={onSubmit}>
          <label style={{display:'block',color:'#9fb0c8',marginBottom:6}}>Nama Website</label>
          <input value={projectName} onChange={e=>setProjectName(e.target.value)} placeholder="contoh: my-project" style={{width:'100%',padding:10,borderRadius:8,background:'rgba(0,0,0,0.4)',border:'1px solid rgba(0,255,255,0.06)',color:'#e6f7ff'}} />
          <label style={{display:'block',color:'#9fb0c8',marginTop:12,marginBottom:6}}>Upload (.zip)</label>
          <input type="file" accept=".zip" onChange={e=>setFile(e.target.files[0])} style={{width:'100%',color:'#e6f7ff'}} />
          <button type="submit" style={{marginTop:14,width:'100%',padding:12,borderRadius:8,background:'linear-gradient(90deg,#00f7ff,#7c2cff)',border:'none',fontWeight:700,color:'#001',cursor:'pointer'}}>⚡ Deploy Sekarang</button>
        </form>
        {status && <p style={{marginTop:12,color:'#ffb6c1'}}>{status}</p>}
        <footer style={{marginTop:16,fontSize:12,color:'#9fb0c8'}}>Made with 💙 YannDev</footer>
      </div>
    </main>
  );
}
