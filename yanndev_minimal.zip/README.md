# YannDev - Cyberpunk Minimal (Next.js)

Simple Next.js project (Cyberpunk Minimal) ready to upload to GitHub and deploy to Vercel.

Features:
- Single-page Neon UI (YannDev)
- Upload ZIP and proxy API to forward to external endpoint
- Ready for Vercel (set environment variables in project settings)

Env variables:
- EXTERNAL_API_ENDPOINT
- EXTERNAL_API_KEY

Don't commit secrets to public repos.
